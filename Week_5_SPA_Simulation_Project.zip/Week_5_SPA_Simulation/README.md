# Week 5 – Single Page Application (SPA) Simulation

## Project structure
- `index.html` – the main HTML container and navigation.
- `style.css` – shared responsive styling, cards, transitions and reduced-motion support.
- `script.js` – client-side routing, DOM rendering, History API, browser back/forward handling, form validation and 404 handling.

## Run the project
Keep all three files in the same folder. Open `index.html` in a modern browser. For the cleanest routing demonstration, use the included navigation links and browser back/forward buttons. A local development server such as VS Code Live Server is recommended because direct nested URL handling depends on server configuration.

## Features to test
1. Select Home, About, Projects and Contact; notice that content changes without a full page reload.
2. Observe the URL path changing for each route.
3. Use browser Back and Forward to revisit routes.
4. Open an unknown route such as `/unknown` on a local server to view the 404 screen.
5. Try submitting the contact form with empty or valid fields.
6. Resize the browser to test the responsive layout.

The contact form is a front-end demonstration only; it does not transmit data to a server.
