const app = document.getElementById("app");
const navLinks = [...document.querySelectorAll("[data-route]")];

const pages = {
  home: () => `
    <section class="page hero">
      <div>
        <p class="eyebrow">WELCOME TO NOVA</p>
        <h1>One page.<br><span>Many possibilities.</span></h1>
        <p class="lead">Explore this small Single Page Application simulation. Move between sections instantly without a full browser page reload.</p>
        <a class="button" href="/projects" data-link>Explore projects →</a>
        <a class="button light" href="/about" data-link>Learn more</a>
      </div>
      <div class="hero-art" aria-label="Decorative application illustration">
        <div class="art-card"><strong>SPA</strong><small>Single Page Experience</small></div>
      </div>
    </section>
    <section class="page">
      <div class="section-head"><p class="eyebrow">OVERVIEW</p><h2>What makes it special?</h2><p>Content changes dynamically while the main page stays loaded.</p></div>
      <div class="cards">
        <article class="card"><div class="card-icon" aria-hidden="true">↗</div><h3>Fast navigation</h3><p>Client-side routing changes the visible view without a complete reload.</p></article>
        <article class="card"><div class="card-icon" aria-hidden="true">⌁</div><h3>Clean interface</h3><p>A consistent layout keeps navigation familiar on every section.</p></article>
        <article class="card"><div class="card-icon" aria-hidden="true">◎</div><h3>Browser history</h3><p>Back and forward buttons restore the previously visited route.</p></article>
      </div>
    </section>`,
  about: () => `
    <section class="page">
      <div class="section-head"><p class="eyebrow">ABOUT THE DEMO</p><h1>A smoother way<br><span>to explore.</span></h1></div>
      <div class="info-panel"><h2>What is a SPA?</h2><p>A Single Page Application is a web application that updates parts of a page dynamically instead of requesting a completely new HTML page for every navigation. JavaScript manages the displayed content and can update the browser URL with the History API.</p><p>This project is a small front-end simulation built with plain HTML, CSS and JavaScript. It demonstrates routing, DOM updates, browser history and basic error handling.</p></div>
    </section>`,
  projects: () => `
    <section class="page">
      <div class="section-head"><p class="eyebrow">SELECTED WORK</p><h1>Practice <span>projects.</span></h1><p class="lead">A few sample cards to demonstrate how a route can display a different set of content.</p></div>
      <div class="cards">
        <article class="card"><div class="card-icon" aria-hidden="true">01</div><h3>Student Portal</h3><p>A sample dashboard concept for viewing student information and updates.</p></article>
        <article class="card"><div class="card-icon" aria-hidden="true">02</div><h3>Task Planner</h3><p>A simple concept for organising daily activities and priorities.</p></article>
        <article class="card"><div class="card-icon" aria-hidden="true">03</div><h3>Portfolio Website</h3><p>A responsive profile page for presenting skills and learning projects.</p></article>
      </div>
    </section>`,
  contact: () => `
    <section class="page">
      <div class="section-head"><p class="eyebrow">GET IN TOUCH</p><h1>Let's <span>connect.</span></h1><p class="lead">This demo form checks the entered details in the browser. It does not send information to a server.</p></div>
      <form class="info-panel contact-form" id="contactForm" novalidate>
        <div class="field"><label for="visitorName">Your name</label><input id="visitorName" name="visitorName" required minlength="2" placeholder="Enter your name"></div>
        <div class="field"><label for="visitorEmail">Email address</label><input id="visitorEmail" name="visitorEmail" type="email" required placeholder="name@example.com"></div>
        <div class="field"><label for="visitorMessage">Message</label><textarea id="visitorMessage" name="visitorMessage" rows="4" required minlength="5" placeholder="Write a short message"></textarea></div>
        <button class="button" type="submit">Check details</button><p id="formFeedback" class="feedback" role="status" aria-live="polite"></p>
      </form>
    </section>`
};

function normalisePath(path) {
  if (!path || path === "/") return "home";
  return path.replace(/\/+$/, "").split("/").filter(Boolean).pop().toLowerCase();
}

function renderRoute() {
  const route = normalisePath(window.location.pathname);
  const page = pages[route];
  navLinks.forEach(link => {
    const active = link.dataset.route === route;
    link.classList.toggle("active", active);
    if (active) link.setAttribute("aria-current", "page");
    else link.removeAttribute("aria-current");
  });

  if (!page) {
    app.innerHTML = `<section class="page error-page"><p class="error-code">404</p><h2>Page not found</h2><p class="lead">The requested section does not exist in this demo.</p><a class="button" href="/" data-link>Return home</a></section>`;
  } else {
    app.innerHTML = page();
  }
  app.focus({preventScroll:true});
}

function navigate(path) {
  const target = path || "/";
  if (window.location.pathname !== target) {
    window.history.pushState({path:target}, "", target);
  }
  renderRoute();
  window.scrollTo({top:0, behavior:"smooth"});
}

document.addEventListener("click", event => {
  const link = event.target.closest("a[data-link]");
  if (!link) return;
  const url = new URL(link.href, window.location.origin);
  if (url.origin !== window.location.origin) return;
  event.preventDefault();
  navigate(url.pathname);
});

window.addEventListener("popstate", renderRoute);

document.addEventListener("submit", event => {
  if (event.target.id !== "contactForm") return;
  event.preventDefault();
  const form = event.target;
  const feedback = document.getElementById("formFeedback");
  if (!form.checkValidity()) {
    form.reportValidity();
    feedback.textContent = "Please complete all fields with valid details.";
    return;
  }
  const name = document.getElementById("visitorName").value.trim();
  feedback.textContent = `Thank you, ${name}! The demo form has been validated.`;
  form.reset();
});

document.getElementById("year").textContent = new Date().getFullYear();
renderRoute();
