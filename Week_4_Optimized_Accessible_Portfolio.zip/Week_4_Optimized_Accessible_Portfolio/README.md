# Week 4 – Optimized and Accessible Student Portfolio

## Project files
- `index.html`: semantic HTML structure, metadata, accessible navigation and form labels.
- `style.css`: responsive styling, reusable variables, visible keyboard focus and reduced-motion support.
- `script.js`: accessible navigation and theme controls, project message and client-side form validation.

## Run
Keep all three files in the same folder and open `index.html` in a browser.

## Testing checklist
1. Resize the browser to desktop and mobile widths.
2. Use Tab and Shift+Tab to navigate the page.
3. Test the skip link, menu, theme button and contact form.
4. Run Chrome Lighthouse for performance/accessibility checks.
5. Run WAVE or axe DevTools for accessibility checks; use WebPageTest for additional loading analysis.

No tool scores are claimed in this project. Run the tools in your own browser to obtain genuine results. The contact form is a front-end demonstration and does not send data to a server.
