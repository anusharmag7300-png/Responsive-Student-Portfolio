const menuToggle=document.getElementById("menuToggle");
const navLinks=document.getElementById("navLinks");
menuToggle.addEventListener("click",()=>{
  const open=navLinks.classList.toggle("show");
  menuToggle.setAttribute("aria-expanded",String(open));
  menuToggle.setAttribute("aria-label",open?"Close navigation menu":"Open navigation menu");
  menuToggle.textContent=open?"✕":"☰";
});
navLinks.querySelectorAll("a").forEach(link=>link.addEventListener("click",()=>{
  navLinks.classList.remove("show");
  menuToggle.setAttribute("aria-expanded","false");
  menuToggle.setAttribute("aria-label","Open navigation menu");
  menuToggle.textContent="☰";
}));
const themeToggle=document.getElementById("themeToggle");
themeToggle.addEventListener("click",()=>{
  const dark=document.body.classList.toggle("dark");
  themeToggle.setAttribute("aria-pressed",String(dark));
  themeToggle.setAttribute("aria-label",dark?"Switch to light mode":"Switch to dark mode");
  themeToggle.textContent=dark?"☀️":"🌙";
});
document.getElementById("showMessageBtn").addEventListener("click",()=>{
  document.getElementById("projectMessage").textContent="Thanks for exploring my projects! I am continuously learning and building.";
});
document.getElementById("contactForm").addEventListener("submit",event=>{
  event.preventDefault();
  const name=document.getElementById("name").value.trim();
  const email=document.getElementById("email").value.trim();
  const message=document.getElementById("message").value.trim();
  const pattern=/^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const errors={
    name:name.length<2?"Please enter at least 2 characters.":"",
    email:pattern.test(email)?"":"Please enter a valid email address.",
    message:message.length<10?"Please enter at least 10 characters.":""
  };
  Object.entries(errors).forEach(([key,value])=>document.getElementById(key+"Error").textContent=value);
  document.getElementById("formFeedback").textContent="";
  const first=Object.keys(errors).find(key=>errors[key]);
  if(first){document.getElementById(first).focus();return;}
  document.getElementById("formFeedback").textContent=`Thank you, ${name}! Your form has been validated successfully.`;
  event.currentTarget.reset();
});
document.getElementById("year").textContent=new Date().getFullYear();
