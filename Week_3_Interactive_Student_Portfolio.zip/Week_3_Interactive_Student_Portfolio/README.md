# Week 3 – Interactive Student Portfolio

This project continues the Week 2 Responsive Student Portfolio and adds JavaScript-based interactivity.

## Files
- `index.html` – webpage structure and content
- `style.css` – responsive styling for desktop, tablet and mobile
- `script.js` – menu toggle, theme switch, project message, contact form validation and dynamic footer year

## How to run
1. Download or clone this repository.
2. Keep all three files in the same folder.
3. Open `index.html` in a web browser.
4. Test the menu, theme button, project message and contact form.

## Note
The contact form is a front-end demonstration. It validates the input in the browser but does not send or store messages on a server.
