// Mobile navigation menu
const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");

menuToggle.addEventListener("click", () => {
  const isOpen = navLinks.classList.toggle("show");
  menuToggle.setAttribute("aria-expanded", isOpen);
  menuToggle.textContent = isOpen ? "✕" : "☰";
});

// Close the mobile menu after selecting a section
navLinks.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("show");
    menuToggle.setAttribute("aria-expanded", "false");
    menuToggle.textContent = "☰";
  });
});

// Dark and light theme toggle
const themeToggle = document.getElementById("themeToggle");
themeToggle.addEventListener("click", () => {
  document.body.classList.toggle("dark");
  const darkModeOn = document.body.classList.contains("dark");
  themeToggle.textContent = darkModeOn ? "☀️" : "🌙";
  themeToggle.setAttribute("aria-label", darkModeOn ? "Switch to light mode" : "Switch to dark mode");
});

// Dynamic project section message
const showMessageBtn = document.getElementById("showMessageBtn");
const projectMessage = document.getElementById("projectMessage");
showMessageBtn.addEventListener("click", () => {
  projectMessage.textContent = "Thanks for exploring my projects! I am continuously learning and building.";
});

// Contact form validation (demo only; no server connection)
const contactForm = document.getElementById("contactForm");
contactForm.addEventListener("submit", (event) => {
  event.preventDefault();

  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const message = document.getElementById("message").value.trim();
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  document.getElementById("nameError").textContent = "";
  document.getElementById("emailError").textContent = "";
  document.getElementById("messageError").textContent = "";
  document.getElementById("formFeedback").textContent = "";

  let isValid = true;
  if (name.length < 2) {
    document.getElementById("nameError").textContent = "Please enter a name with at least 2 characters.";
    isValid = false;
  }
  if (!emailPattern.test(email)) {
    document.getElementById("emailError").textContent = "Please enter a valid email address.";
    isValid = false;
  }
  if (message.length < 10) {
    document.getElementById("messageError").textContent = "Please write a message of at least 10 characters.";
    isValid = false;
  }

  if (isValid) {
    document.getElementById("formFeedback").textContent =
      `Thank you, ${name}! Your form has been validated successfully.`;
    contactForm.reset();
  }
});

// Automatically update the footer year
document.getElementById("year").textContent = new Date().getFullYear();
