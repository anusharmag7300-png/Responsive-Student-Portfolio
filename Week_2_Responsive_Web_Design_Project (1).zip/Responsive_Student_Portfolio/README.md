# Responsive Student Portfolio

A beginner-friendly responsive portfolio website created with HTML5 and CSS3.

## Files
- `index.html` — semantic webpage structure and content
- `style.css` — styling, flexible grid layouts, and responsive media queries

## Features
- Responsive navigation and page sections
- CSS Grid and flexible layouts
- Media queries for tablet, mobile, and small mobile screens
- Fluid typography using `clamp()`
- Clear section structure: Home, About, Skills, Projects, Contact

## Run locally
1. Download or clone this repository.
2. Open `index.html` in a web browser.
3. Resize the browser window or use Developer Tools → Toggle device toolbar to test different screen sizes.

## Customisation
Replace the sample email address `hello@example.com` with your own contact email. Update the text and project details to match your actual work.
